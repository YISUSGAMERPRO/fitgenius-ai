"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/test-gemini.ts
var test_gemini_exports = {};
__export(test_gemini_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(test_gemini_exports);
var import_generative_ai = require("@google/generative-ai");
var handler = async (event) => {
  try {
    const geminiApiKey = process.env.GEMINI_API_KEY;
    if (!geminiApiKey) {
      return {
        statusCode: 503,
        body: JSON.stringify({ error: "GEMINI_API_KEY no configurada" })
      };
    }
    console.log("\u{1F916} Probando Gemini API...");
    const genAI = new import_generative_ai.GoogleGenerativeAI(geminiApiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    const prompt = 'Di "Hola" en JSON: {"mensaje": "tu respuesta"}';
    console.log("\u{1F4EE} Enviando prompt corto...");
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    console.log("\u2705 Respuesta recibida:", text);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        success: true,
        apiKeyPresent: true,
        responseLength: text?.length || 0,
        responsePreview: text?.substring(0, 200),
        fullResponse: text
      })
    };
  } catch (error) {
    console.error("\u274C Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: error.message,
        stack: error.stack,
        type: error.constructor.name
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
