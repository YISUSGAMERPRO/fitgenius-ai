"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/swap-exercise.ts
var swap_exercise_exports = {};
__export(swap_exercise_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(swap_exercise_exports);
var import_generative_ai = require("@google/generative-ai");
var handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  try {
    const {
      currentExercise,
      // El ejercicio actual a reemplazar
      muscleGroup,
      // Grupo muscular objetivo
      availableEquipment,
      // Equipo disponible del usuario
      exercisesToAvoid,
      // Lista de ejercicios a evitar (ya en la rutina)
      userProfile
      // Perfil del usuario para personalización
    } = JSON.parse(event.body || "{}");
    if (!currentExercise || !muscleGroup) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Se requiere currentExercise y muscleGroup" })
      };
    }
    const geminiApiKey = process.env.GEMINI_API_KEY;
    if (!geminiApiKey) {
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({ error: "GEMINI_API_KEY no configurada" })
      };
    }
    console.log("\u{1F504} Buscando alternativa para:", currentExercise);
    const genAI = new import_generative_ai.GoogleGenerativeAI(geminiApiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    const avoidList = exercisesToAvoid?.length ? `NO incluyas estos ejercicios (ya est\xE1n en la rutina): ${exercisesToAvoid.join(", ")}` : "";
    const equipmentInfo = availableEquipment?.length ? `Equipamiento disponible: ${availableEquipment.join(", ")}` : "El usuario puede no tener equipamiento especializado, prioriza ejercicios con peso corporal o mancuernas b\xE1sicas";
    const injuriesInfo = userProfile?.injuries ? `IMPORTANTE: El usuario tiene las siguientes limitaciones: ${userProfile.injuries}. Evita ejercicios contraindicados.` : "";
    const prompt = `Eres un entrenador personal experto. El usuario quiere REEMPLAZAR este ejercicio:

EJERCICIO ACTUAL: ${currentExercise}
GRUPO MUSCULAR: ${muscleGroup}
${equipmentInfo}
${injuriesInfo}
${avoidList}

Genera UN ejercicio alternativo que:
1. Trabaje el mismo grupo muscular
2. Sea igual o m\xE1s efectivo
3. Use el equipamiento disponible (o peso corporal si no hay)
4. Sea seguro para las limitaciones del usuario

Responde \xDANICAMENTE con este JSON (sin markdown, sin explicaciones):
{
  "name": "Nombre del ejercicio alternativo",
  "sets": 3-5 (n\xFAmero variable seg\xFAn intensidad),
  "reps": "rango de repeticiones",
  "rest": "tiempo de descanso en segundos con 's'",
  "muscleGroup": "${muscleGroup}",
  "category": "main",
  "tempo": "tempo del movimiento (ej: 2-1-2-0)",
  "description": "Descripci\xF3n detallada de c\xF3mo ejecutar el ejercicio correctamente",
  "tips": "Consejos de forma y errores comunes a evitar",
  "videoQuery": "t\xE9rmino de b\xFAsqueda para YouTube",
  "alternatives": [
    {
      "name": "Otra alternativa posible",
      "reason": "Por qu\xE9 es buena opci\xF3n"
    },
    {
      "name": "Segunda alternativa",
      "reason": "Por qu\xE9 es buena opci\xF3n"
    }
  ],
  "whyBetter": "Breve explicaci\xF3n de por qu\xE9 este ejercicio es buena alternativa al original"
}`;
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    console.log("\u2705 Respuesta recibida");
    if (!text) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: "Respuesta vac\xEDa de Gemini" })
      };
    }
    let json = text;
    const match = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (match) json = match[1];
    else {
      const start = text.indexOf("{");
      const end = text.lastIndexOf("}");
      if (start > -1 && end > -1) json = text.substring(start, end + 1);
    }
    const newExercise = JSON.parse(json);
    console.log("\u{1F504} Ejercicio alternativo generado:", newExercise.name);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        originalExercise: currentExercise,
        newExercise
      })
    };
  } catch (error) {
    console.error("\u274C Error:", error?.message);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: error?.message || "Error desconocido" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
