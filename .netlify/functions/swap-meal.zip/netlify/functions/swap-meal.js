"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/swap-meal.ts
var swap_meal_exports = {};
__export(swap_meal_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(swap_meal_exports);
var import_generative_ai = require("@google/generative-ai");
var handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  try {
    const {
      currentMeal,
      // El platillo actual a reemplazar
      mealType,
      // Tipo de comida (Desayuno, Almuerzo, etc.)
      dietType,
      // Tipo de dieta (Keto, Vegana, etc.)
      targetMacros,
      // Macros objetivo para esta comida
      preferences,
      // Preferencias del usuario
      mealsToAvoid,
      // Lista de platillos a evitar (ya en el plan)
      userProfile
      // Perfil del usuario para personalización
    } = JSON.parse(event.body || "{}");
    if (!currentMeal || !mealType) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Se requiere currentMeal y mealType" })
      };
    }
    const geminiApiKey = process.env.GEMINI_API_KEY;
    if (!geminiApiKey) {
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({ error: "GEMINI_API_KEY no configurada" })
      };
    }
    console.log("\u{1F504} Buscando alternativa para:", currentMeal.name);
    const genAI = new import_generative_ai.GoogleGenerativeAI(geminiApiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    const avoidList = mealsToAvoid?.length ? `NO incluyas estos platillos (ya est\xE1n en el plan): ${mealsToAvoid.join(", ")}` : "";
    const preferencesText = preferences?.length ? `PREFERENCIAS OBLIGATORIAS: ${preferences.join(", ")}` : "";
    const macrosText = targetMacros ? `MACROS OBJETIVO: ~${targetMacros.calories} kcal, ${targetMacros.protein}g prote\xEDna, ${targetMacros.carbs}g carbos, ${targetMacros.fats}g grasas` : "";
    const dietTypeText = dietType ? `TIPO DE DIETA: ${dietType}. Respeta estrictamente este tipo de alimentaci\xF3n.` : "";
    const prompt = `Eres un nutricionista experto. El usuario quiere REEMPLAZAR este platillo:

PLATILLO ACTUAL: ${currentMeal.name}
TIPO DE COMIDA: ${mealType}
${dietTypeText}
${macrosText}
${preferencesText}
${avoidList}

DATOS DEL USUARIO:
- Objetivo: ${userProfile?.goal || "No especificado"}
- Peso: ${userProfile?.weight || "No especificado"} kg
- Actividad: ${userProfile?.activityLevel || "No especificado"}

Genera UN platillo alternativo que:
1. Sea apropiado para ${mealType}
2. Tenga macros similares al objetivo
3. Respete el tipo de dieta y preferencias
4. Sea diferente pero igual de nutritivo y sabroso
5. Incluya instrucciones de preparaci\xF3n

Responde \xDANICAMENTE con este JSON (sin markdown, sin explicaciones):
{
  "name": "Nombre del platillo alternativo",
  "type": "${mealType}",
  "description": "Descripci\xF3n apetitosa del platillo",
  "ingredients": ["ingrediente 1 (cantidad)", "ingrediente 2 (cantidad)"],
  "instructions": ["Paso 1 de preparaci\xF3n", "Paso 2", "Paso 3"],
  "calories": n\xFAmero,
  "protein": n\xFAmero,
  "carbs": n\xFAmero,
  "fats": n\xFAmero,
  "prepTime": "X minutos",
  "alternatives": [
    {
      "name": "Alternativa de ingrediente",
      "swapFor": "ingrediente que reemplaza",
      "reason": "Por qu\xE9 es buena alternativa"
    },
    {
      "name": "Otra alternativa",
      "swapFor": "ingrediente que reemplaza",
      "reason": "Por qu\xE9 es buena alternativa"
    }
  ],
  "whyBetter": "Breve explicaci\xF3n de por qu\xE9 este platillo es buena alternativa"
}`;
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    console.log("\u2705 Respuesta recibida");
    if (!text) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: "Respuesta vac\xEDa de Gemini" })
      };
    }
    let json = text;
    const match = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (match) json = match[1];
    else {
      const start = text.indexOf("{");
      const end = text.lastIndexOf("}");
      if (start > -1 && end > -1) json = text.substring(start, end + 1);
    }
    const newMeal = JSON.parse(json);
    console.log("\u{1F504} Platillo alternativo generado:", newMeal.name);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        originalMeal: currentMeal.name,
        newMeal
      })
    };
  } catch (error) {
    console.error("\u274C Error:", error?.message);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: error?.message || "Error desconocido" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
