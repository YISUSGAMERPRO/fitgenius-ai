"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/api.js
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
var import_pg = require("pg");
var pool = new import_pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers };
  }
  const path = event.path.replace("/.netlify/functions/api", "") || "/";
  const method = event.httpMethod;
  const body = event.body ? JSON.parse(event.body) : {};
  try {
    if (path === "/login" && method === "POST") {
      const { username, password } = body;
      const result = await pool.query(
        "SELECT * FROM users WHERE username = $1 AND password = $2",
        [username, password]
      );
      if (result.rows.length === 0) {
        return {
          statusCode: 401,
          headers,
          body: JSON.stringify({ error: "Credenciales inv\xE1lidas" })
        };
      }
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(result.rows[0])
      };
    }
    if (path === "/members" && method === "GET") {
      const result = await pool.query("SELECT * FROM gym_members");
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(result.rows)
      };
    }
    if (path === "/generate-workout" && method === "POST") {
      if (!ai) {
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({ error: "IA no disponible" })
        };
      }
      const { userGoal, frequency, duration } = body;
      const prompt = `Crea una rutina de ejercicios detallada:
- Objetivo: ${userGoal}
- Frecuencia: ${frequency} d\xEDas/semana
- Duraci\xF3n de sesi\xF3n: ${duration} minutos
Formato: JSON con ejercicios, series, repeticiones`;
      const response = await ai.generateContent(prompt);
      const text = response.response?.text?.();
      const jsonMatch = text?.match(/\{[\s\S]*\}/);
      const workout = jsonMatch ? JSON.parse(jsonMatch[0]) : { error: "No se pudo generar" };
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(workout)
      };
    }
    if (path === "/generate-diet" && method === "POST") {
      if (!ai) {
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({ error: "IA no disponible" })
        };
      }
      const { userGoal, calories, dietary } = body;
      const prompt = `Crea un plan de dieta detallado:
- Objetivo: ${userGoal}
- Calor\xEDas/d\xEDa: ${calories}
- Restricciones: ${dietary}
Formato: JSON con comidas, macros, recetas`;
      const response = await ai.generateContent(prompt);
      const text = response.response?.text?.();
      const jsonMatch = text?.match(/\{[\s\S]*\}/);
      const diet = jsonMatch ? JSON.parse(jsonMatch[0]) : { error: "No se pudo generar" };
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(diet)
      };
    }
    if (path === "/save-workout" && method === "POST") {
      const { userId, title, planData } = body;
      const id = Date.now().toString();
      await pool.query(
        "INSERT INTO workout_plans (id, user_id, title, plan_data) VALUES ($1, $2, $3, $4)",
        [id, userId, title, JSON.stringify(planData)]
      );
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ id, success: true })
      };
    }
    if (path === "/save-diet" && method === "POST") {
      const { userId, title, planData } = body;
      const id = Date.now().toString();
      await pool.query(
        "INSERT INTO diet_plans (id, user_id, title, plan_data) VALUES ($1, $2, $3, $4)",
        [id, userId, title, JSON.stringify(planData)]
      );
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ id, success: true })
      };
    }
    if (path === "/health" && method === "GET") {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ status: "OK", timestamp: (/* @__PURE__ */ new Date()).toISOString() })
      };
    }
    return {
      statusCode: 404,
      headers,
      body: JSON.stringify({ error: "Ruta no encontrada" })
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
