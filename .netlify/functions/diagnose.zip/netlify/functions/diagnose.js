"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/diagnose.ts
var diagnose_exports = {};
__export(diagnose_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(diagnose_exports);
var handler = async (event) => {
  try {
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: "Diagnostic function working",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        env: {
          geminiKey: process.env.GEMINI_API_KEY ? "\u2705 Set" : "\u274C Missing",
          databaseUrl: process.env.NETLIFY_DATABASE_URL_UNPOOLED ? "\u2705 Set" : "\u274C Missing",
          nodeEnv: process.env.NODE_ENV
        }
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error?.message || "Unknown error" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
