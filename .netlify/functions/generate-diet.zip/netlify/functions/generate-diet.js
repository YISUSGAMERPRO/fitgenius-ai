"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/generate-diet.ts
var generate_diet_exports = {};
__export(generate_diet_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(generate_diet_exports);
var import_generative_ai = require("@google/generative-ai");
function calculateIMC(weight, heightCm) {
  if (!weight || !heightCm || heightCm <= 0) return { value: 0, category: "No calculable", dietRecommendations: "" };
  const heightM = heightCm / 100;
  const imc = parseFloat((weight / (heightM * heightM)).toFixed(1));
  if (imc < 18.5) {
    return {
      value: imc,
      category: "Bajo peso",
      dietRecommendations: "Aumentar super\xE1vit cal\xF3rico. Incluir m\xE1s carbohidratos complejos y prote\xEDnas. Comidas m\xE1s frecuentes (6-7 al d\xEDa). A\xF1adir snacks cal\xF3ricos saludables."
    };
  } else if (imc < 25) {
    return {
      value: imc,
      category: "Peso normal",
      dietRecommendations: "Mantener balance cal\xF3rico seg\xFAn objetivo. Distribuci\xF3n equilibrada de macronutrientes."
    };
  } else if (imc < 30) {
    return {
      value: imc,
      category: "Sobrepeso",
      dietRecommendations: "D\xE9ficit cal\xF3rico moderado (15-20%). Aumentar prote\xEDnas para preservar m\xFAsculo. Reducir carbohidratos refinados. Priorizar vegetales y fibra."
    };
  } else if (imc < 35) {
    return {
      value: imc,
      category: "Obesidad Grado I",
      dietRecommendations: "D\xE9ficit cal\xF3rico estructurado (20-25%). Alta prote\xEDna (2g/kg ideal). Eliminar az\xFAcares y ultraprocesados. Plan de comidas estricto con horarios definidos."
    };
  } else {
    return {
      value: imc,
      category: "Obesidad Grado II-III",
      dietRecommendations: "IMPORTANTE: Plan supervisado m\xE9dicamente. D\xE9ficit cal\xF3rico controlado. Eliminar ultraprocesados y az\xFAcares. Comidas peque\xF1as y frecuentes. Supervisi\xF3n con nutricionista cl\xEDnico obligatoria."
    };
  }
}
function calculateNutritionNeeds(profile) {
  const weight = profile.weight || 70;
  const height = profile.height || 170;
  const age = profile.age || 30;
  const gender = profile.gender || "Masculino";
  const activityLevel = profile.activityLevel || "Moderado";
  const goal = profile.goal || "Mantenimiento";
  let tmb;
  if (gender === "Masculino" || gender === "Male") {
    tmb = 88.362 + 13.397 * weight + 4.799 * height - 5.677 * age;
  } else {
    tmb = 447.593 + 9.247 * weight + 3.098 * height - 4.33 * age;
  }
  const activityFactors = {
    "Sedentario": 1.2,
    "Ligero (1-2 d\xEDas/semana)": 1.375,
    "Moderado (3-5 d\xEDas/semana)": 1.55,
    "Activo (6-7 d\xEDas/semana)": 1.725,
    "Atleta profesional": 1.9
  };
  const activityFactor = activityFactors[activityLevel] || 1.55;
  let tdee = tmb * activityFactor;
  let proteinPerKg = 1.6;
  let carbPercent = 0.45;
  let fatPercent = 0.25;
  if (goal.includes("Perder") || goal.includes("grasa") || goal.includes("Lose")) {
    tdee *= 0.8;
    proteinPerKg = 2.2;
    carbPercent = 0.35;
    fatPercent = 0.3;
  } else if (goal.includes("Ganar") || goal.includes("m\xFAsculo") || goal.includes("Gain")) {
    tdee *= 1.15;
    proteinPerKg = 2;
    carbPercent = 0.5;
    fatPercent = 0.25;
  } else if (goal.includes("Fuerza")) {
    proteinPerKg = 2.2;
    carbPercent = 0.4;
    fatPercent = 0.3;
  }
  const calories = Math.round(tdee);
  const protein = Math.round(weight * proteinPerKg);
  const proteinCalories = protein * 4;
  const remainingCalories = calories - proteinCalories;
  const carbs = Math.round(remainingCalories * carbPercent / 4);
  const fats = Math.round(remainingCalories * fatPercent / 9);
  return { calories, protein, carbs, fats };
}
function determineMacrosByDietAndGoal(dietType, goal, baseNeeds) {
  const macros = { ...baseNeeds };
  if (dietType.includes("Cetog\xE9nica") || dietType.includes("Keto")) {
    macros.fats = Math.round(macros.calories * 0.7 / 9);
    macros.protein = Math.round(macros.calories * 0.25 / 4);
    macros.carbs = Math.round(macros.calories * 0.05 / 4);
  } else if (dietType.includes("Vegetariana")) {
    macros.protein = Math.round(macros.protein * 1.1);
    macros.carbs = Math.round(macros.carbs * 1.15);
  } else if (dietType.includes("Ayuno Intermitente")) {
    macros.protein = Math.round(macros.protein * 1.15);
  } else if (dietType.includes("Baja en Carbohidratos")) {
    macros.carbs = Math.round(macros.carbs * 0.6);
    macros.fats = Math.round(macros.fats * 1.3);
  }
  return macros;
}
var handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  try {
    const { userId, profile, dietType, preferences, budget, mealsPerDay, location } = JSON.parse(event.body || "{}");
    if (!userId || !profile || !dietType) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Faltan par\xE1metros" })
      };
    }
    const geminiApiKey = process.env.GEMINI_API_KEY;
    if (!geminiApiKey) {
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({ error: "GEMINI_API_KEY no configurada" })
      };
    }
    console.log("\u{1F37D}\uFE0F Generando dieta personalizada", dietType);
    const genAI = new import_generative_ai.GoogleGenerativeAI(geminiApiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    const imcData = calculateIMC(profile.weight, profile.height);
    const nutritionNeeds = calculateNutritionNeeds(profile);
    const dietMacros = determineMacrosByDietAndGoal(dietType, profile.goal, nutritionNeeds);
    const preferencesText = preferences && preferences.length > 0 ? `RESTRICCIONES/PREFERENCIAS OBLIGATORIAS: ${preferences.join(", ")}. RESPETA ESTRICTAMENTE.` : "Sin preferencias espec\xEDficas.";
    const userLocation = location || profile.location || "";
    const locationText = userLocation ? `UBICACI\xD3N: ${userLocation}. Usa ingredientes y precios promedio de la zona. Prioriza alimentos locales y econ\xF3micos seg\xFAn la regi\xF3n. Ajusta el men\xFA y la lista de compras a la disponibilidad y costo real de insumos en esa ubicaci\xF3n.` : "";
    const budgetText = budget && budget.amount > 0 ? `PRESUPUESTO: ${budget.amount} ${budget.frequency}. PRIORIZA ingredientes econ\xF3micos y accesibles.` : "";
    const healthConditions = profile.injuries ? `CONDICIONES M\xC9DICAS: ${profile.injuries}. REQUIERE alimentos antiinflamatorios o seg\xFAn la condici\xF3n.` : "";
    const mealCount = mealsPerDay || 5;
    const prompt = `Eres nutricionista deportivo certificado especializado en EVIDENCIA CIENT\xCDFICA. 15+ a\xF1os de experiencia.

IMPORTANTE: Crea plan \xDANICO Y COMPLETAMENTE PERSONALIZADO. NO plantillas gen\xE9ricas.

## USUARIO (\xDANICA COMBINACI\xD3N):
- Nombre: ${profile.name || "Usuario"}
- Edad: ${profile.age}, Peso: ${profile.weight}kg, Altura: ${profile.height}cm
- **IMC: ${imcData.value} - ${imcData.category}**
- Objetivo: ${profile.goal} | Actividad: ${profile.activityLevel}
- Tipo de cuerpo: ${profile.bodyType || "No especificado"}
${userLocation ? `
- Ubicaci\xF3n: ${userLocation}` : ""}

## MACROS CIENT\xCDFICAMENTE CALCULADOS:
- Calor\xEDas: ${dietMacros.calories} kcal
- Prote\xEDna: ${dietMacros.protein}g
- Carbohidratos: ${dietMacros.carbs}g
- Grasas: ${dietMacros.fats}g

## DIETA: ${dietType}
${preferencesText}
${budgetText}
${locationText}
${healthConditions}

## COMIDAS: ${mealCount} diarias

## REQUISITOS OBLIGATORIOS:
1. **7 D\xCDAS COMPLETAMENTE DIFERENTES**: Platillos \xDANICOS cada d\xEDa. NO repetir desayunos/almuerzos
2. **${mealCount} COMIDAS VARIADAS**: Desayuno, snacks y comidas principales
3. **MACROS PRECISOS**: ${dietMacros.calories}\xB150 kcal, prote\xEDna ${dietMacros.protein}\xB13g
4. **2 ALTERNATIVAS POR PLATILLO**: Para ingredientes espec\xEDficos
5. **ALIMENTOS REALES**: Sin suplementos gen\xE9ricos
6. **TIMING NUTRICIONAL**: Prote\xEDna distribuida, carbos pre/post-entrenamiento
7. **ADAPTADO AL IMC**: ${imcData.dietRecommendations}

## EVIDENCIA CIENT\xCDFICA:
- Distribuir prote\xEDna en 4-5 tomas (Campbell 2016)
- Timing de carbohidratos seg\xFAn actividad
- \xCDndice gluc\xE9mico moderado
- Fibra 25-30g m\xEDnimo
- Grasas insaturadas 75%+

## JSON REQUERIDO (SOLO JSON):
{
  "title": "Plan Nutricional ${dietType}",
  "subtitle": "Personalizado para ${profile.goal}",
  "summary": "Resumen ejecutivo \xFAnico",
  "dailyTargets": {
    "calories": ${dietMacros.calories},
    "protein": ${dietMacros.protein},
    "carbs": ${dietMacros.carbs},
    "fats": ${dietMacros.fats}
  },
  "mealTiming": {
    "breakfast": "8:00 AM",
    "snackAm": "10:30 AM",
    "lunch": "1:00 PM",
    "snackPm": "4:00 PM",
    "dinner": "7:00 PM"
  },
  "schedule": [
    {
      "day": "Lunes - NOMBRE ESPEC\xCDFICO",
      "dayGoal": "Descripci\xF3n del enfoque",
      "totalCalories": ${dietMacros.calories},
      "totalProtein": ${dietMacros.protein},
      "meals": [
        {
          "name": "Nombre atractivo \xFAnico",
          "type": "Desayuno|Snack AM|Almuerzo|Snack PM|Cena",
          "description": "Descripci\xF3n apetitosa",
          "ingredients": ["ingrediente 1 (cantidad)"],
          "instructions": ["Paso 1", "Paso 2"],
          "cookingTime": "XX min",
          "calories": XXX,
          "protein": XX,
          "carbs": XX,
          "fats": XX,
          "fiber": XX,
          "prepDifficulty": "F\xE1cil|Intermedio|Avanzado",
          "nutritionBenefit": "Por qu\xE9 beneficia",
          "alternatives": [
            {"ingredient": "a reemplazar", "with": "alternativa", "reason": "Por qu\xE9"}
          ]
        }
      ]
    }
  ],
  "scientificReferences": ["Campbell et al. 2016", "Helms et al. 2014"],
  "hydrationPlan": "Litros seg\xFAn peso",
  "supplementRecommendation": "Solo si es necesario",
  "weeklyShoppingList": ["ingrediente 1"],
  "mealPrepStrategy": "Estrategia eficiente"
}

RESTRICCIONES:
- NO repetir platillos 7 d\xEDas
- NO nombres gen\xE9ricos
- CADA alternativa viable
- SOLO JSON`;
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    if (!text) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: "Respuesta vac\xEDa de Gemini" })
      };
    }
    let json = text;
    const match = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (match) json = match[1];
    else {
      const start = text.indexOf("{");
      const end = text.lastIndexOf("}");
      if (start > -1 && end > -1) json = text.substring(start, end + 1);
    }
    const planId = Date.now().toString();
    const parsedPlan = JSON.parse(json);
    const dietPlan = {
      id: planId,
      ...parsedPlan,
      title: parsedPlan.title || dietType,
      startDate: (/* @__PURE__ */ new Date()).toISOString(),
      calculatedTargets: dietMacros
    };
    const railwayUrl = process.env.RAILWAY_API_URL || process.env.VITE_API_URL || "https://fitgenius-ai-production.up.railway.app";
    if (userId) {
      try {
        const saveBody = {
          userId,
          title: dietPlan.title || "Plan de Dieta",
          planData: dietPlan
        };
        console.log("\u{1F4E4} Guardando dieta en:", railwayUrl);
        const saveResponse = await fetch(`${railwayUrl}/api/save-diet`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(saveBody)
        });
        if (saveResponse.ok) {
          console.log("\u2705 Dieta guardada");
        } else {
          console.warn("\u26A0\uFE0F No se guard\xF3 en BD");
        }
      } catch (dbErr) {
        console.warn("\u26A0\uFE0F No se guard\xF3:", dbErr?.message);
      }
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(dietPlan)
    };
  } catch (error) {
    console.error("\u274C Error:", error?.message);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: error?.message || "Error desconocido" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
