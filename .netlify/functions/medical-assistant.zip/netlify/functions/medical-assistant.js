"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/medical-assistant.ts
var medical_assistant_exports = {};
__export(medical_assistant_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(medical_assistant_exports);
var import_generative_ai = require("@google/generative-ai");
function calculateIMC(weight, heightCm) {
  if (!weight || !heightCm || heightCm <= 0) return { value: 0, category: "No calculable" };
  const heightM = heightCm / 100;
  const imc = parseFloat((weight / (heightM * heightM)).toFixed(1));
  if (imc < 18.5) return { value: imc, category: "Bajo peso" };
  else if (imc < 25) return { value: imc, category: "Peso normal" };
  else if (imc < 30) return { value: imc, category: "Sobrepeso" };
  else if (imc < 35) return { value: imc, category: "Obesidad Grado I" };
  else if (imc < 40) return { value: imc, category: "Obesidad Grado II" };
  else return { value: imc, category: "Obesidad Grado III" };
}
var handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  try {
    const {
      messages,
      // Historial de conversación
      userProfile,
      // Perfil del usuario
      workout,
      // Plan de entrenamiento actual (opcional)
      diet
      // Plan de dieta actual (opcional)
    } = JSON.parse(event.body || "{}");
    if (!messages || !userProfile) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Se requiere messages y userProfile" })
      };
    }
    const geminiApiKey = process.env.GEMINI_API_KEY;
    if (!geminiApiKey) {
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({ error: "GEMINI_API_KEY no configurada" })
      };
    }
    console.log("\u{1FA7A} Dr. FitGenius procesando consulta...");
    const genAI = new import_generative_ai.GoogleGenerativeAI(geminiApiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    const imcData = calculateIMC(userProfile.weight, userProfile.height);
    const userContext = `
## PERFIL DEL PACIENTE:
- Nombre: ${userProfile.name || "Usuario"}
- Edad: ${userProfile.age} a\xF1os
- Peso: ${userProfile.weight} kg
- Altura: ${userProfile.height} cm
- **IMC: ${imcData.value} (${imcData.category})**
- G\xE9nero: ${userProfile.gender}
- Objetivo fitness: ${userProfile.goal}
- Nivel de actividad: ${userProfile.activityLevel}
- Tipo de cuerpo: ${userProfile.bodyType || "No especificado"}
- Lesiones/Condiciones previas: ${userProfile.injuries || "Ninguna reportada"}
`;
    const workoutContext = workout ? `
## PLAN DE ENTRENAMIENTO ACTUAL:
- Nombre: ${workout.title}
- Tipo: ${workout.frequency}
- Duraci\xF3n: ${workout.estimatedDuration}
- Dificultad: ${workout.difficulty}
${workout.medicalAnalysis?.modifications?.length ? `- Modificaciones m\xE9dicas aplicadas: ${workout.medicalAnalysis.modifications.join(", ")}` : ""}
` : "";
    const dietContext = diet ? `
## PLAN NUTRICIONAL ACTUAL:
- Tipo de dieta: ${diet.title}
- Calor\xEDas diarias: ${diet.dailyTargets?.calories} kcal
- Prote\xEDna: ${diet.dailyTargets?.protein}g
- Carbohidratos: ${diet.dailyTargets?.carbs}g
- Grasas: ${diet.dailyTargets?.fats}g
` : "";
    const conversationHistory = messages.map(
      (m) => `${m.role === "user" ? "PACIENTE" : "DR. FITGENIUS"}: ${m.text}`
    ).join("\n\n");
    const systemPrompt = `Eres el **Dr. FitGenius**, un asistente m\xE9dico deportivo especializado con las siguientes credenciales y caracter\xEDsticas:

## TU ROL:
- M\xE9dico deportivo virtual con especializaci\xF3n en:
  \u2022 Lesiones musculoesquel\xE9ticas deportivas
  \u2022 Nutrici\xF3n deportiva y suplementaci\xF3n
  \u2022 Fisiolog\xEDa del ejercicio
  \u2022 Recuperaci\xF3n y prevenci\xF3n de lesiones
  \u2022 Protocolos de sue\xF1o y descanso
  \u2022 Farmacolog\xEDa deportiva b\xE1sica

## REGLAS CR\xCDTICAS DE SEGURIDAD:
1. **NUNCA** diagnostiques condiciones graves definitivamente - siempre recomienda consultar a un m\xE9dico real
2. **NUNCA** recetes medicamentos con receta m\xE9dica
3. Si detectas s\xEDntomas de emergencia (dolor de pecho, dificultad respiratoria, p\xE9rdida de consciencia), responde con "[ALERTA M\xC9DICA]" al inicio
4. Siempre aclara que eres una IA y no reemplazas la atenci\xF3n m\xE9dica profesional

## TU ESTILO DE COMUNICACI\xD3N:
- Profesional pero cercano y emp\xE1tico
- Usa lenguaje claro, evita jerga m\xE9dica excesiva
- Estructura tus respuestas con vi\xF1etas o pasos cuando sea apropiado
- S\xE9 espec\xEDfico y pr\xE1ctico en tus recomendaciones
- Relaciona las respuestas con el contexto del paciente (su rutina, dieta, objetivos)

## CAPACIDADES ESPECIALES:
- Puedes sugerir modificaciones a ejercicios bas\xE1ndote en dolencias
- Puedes recomendar suplementos seguros (creatina, prote\xEDna, vitaminas, etc.)
- Puedes crear protocolos de recuperaci\xF3n (hielo/calor, estiramientos, descanso)
- Puedes analizar si ciertos s\xEDntomas est\xE1n relacionados con el entrenamiento o dieta

## FORMATO DE RESPUESTA:
- Usa **negritas** para t\xE9rminos importantes
- Usa vi\xF1etas (\u2022) para listas
- Mant\xE9n respuestas concisas pero completas (150-300 palabras idealmente)
- Si es una emergencia, comienza con [ALERTA M\xC9DICA]

${userContext}
${workoutContext}
${dietContext}

## HISTORIAL DE CONVERSACI\xD3N:
${conversationHistory}

Responde a la \xFAltima consulta del paciente de manera profesional, emp\xE1tica y \xFAtil. Recuerda relacionar tu respuesta con su perfil, entrenamiento y/o dieta cuando sea relevante.`;
    const result = await model.generateContent(systemPrompt);
    const response = await result.response;
    const text = response.text();
    if (!text) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: "Respuesta vac\xEDa de Gemini" })
      };
    }
    console.log("\u2705 Dr. FitGenius respondi\xF3");
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        response: text
      })
    };
  } catch (error) {
    console.error("\u274C Error:", error?.message);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: error?.message || "Error desconocido" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
